A package for ift vpn module
