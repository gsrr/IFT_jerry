

def create_user():
	cmds = [
		"useradmin user add %s -p 11111111 -s on -d off -z a@0",
		"useradmin user add %s -p 11111111 -s on -d off -z b@0"
	]
	with open("/root/user.create", "w") as fw:
		name = "test"
		for i in xrange(20000):	
			for cmd in cmds:
				fw.write(cmd%(name + str(i)) + "\n")	

def main():
	create_user()

if __name__ == "__main__":
	main()
