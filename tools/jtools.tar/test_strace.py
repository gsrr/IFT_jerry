import pwd

print pwd.getpwuid(100001)
