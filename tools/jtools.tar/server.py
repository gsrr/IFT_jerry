import socket
import threading
import sys

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_address = ('10.254.255.100', 10000)
sock.bind(server_address)
sock.listen(10)

def func_pwd(client):
	import pwd
	while True:
		pwd.getpwuid(100001)

def func_echo(client):
	print func_echo
	client.send("echo ok")
	client.close()

while True:
	client, addr = sock.accept()
	print client, addr
	data = client.recv(256)
	func = getattr(sys.modules[__name__], "func_" + data)
	threading.Thread(target = func, args = (client,)).start()
