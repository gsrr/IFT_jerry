import threading
import socket
import time
import sys


def func_pwd(sock):
	sock.send("pwd")

def func_echo(sock):
	st = time.time()
	sock.send("echo")
	data = sock.recv(256)
	print data
	print time.time() - st

def main():
	while True:
		name = raw_input("Enter func name:")
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		server_address = ('10.254.255.100', 10000)
		sock.connect(server_address)
		func = getattr(sys.modules[__name__], "func_" + name)
		threading.Thread(target = func, args = (sock,)).start()
	

if __name__ == "__main__":
	main()
