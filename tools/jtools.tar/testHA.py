#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import traceback
import copy
import sys
import base64
import subprocess
import datetime
import random, string
import hmac
from hashlib import sha1
from urllib import unquote
from pwd import getpwuid


def test_heart(ha):
	while True:
		ret = ha.updateHeartbeat()
		print ret

if __name__ == "__main__":
	try:
		sys.path.append("/usr/local/NAS/misc/HAAgent")
		from NASHAComm import *
		HA = NASHAComm("10.254.255.100")
		func = getattr(sys.modules[__name__], "test_" + sys.argv[1])	
		func(HA)
	except:
		pass
	finally:
		HA.closeSocket()
		

		
